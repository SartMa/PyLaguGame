level_0 = {
    'level_bg' : '../level/0/level_0_level_bg.csv',
    'level' : '../level/0/level_0_level.csv',
    'enemy' : '../level/0/level_0_enemy.csv',
    'enemy_constraint' : '../level/0/level_0_enemy_constraints.csv',
    'enemy2' : '../level/0/level_0_enemy2.csv',
    'enemy3' : '../level/0/level_0_enemy3.csv',
    'player' : '../level/0/level_0_player.csv',
    'chest' : '../level/0/level_0_chest.csv',
    'ladder' : '../level/0/level_0_ladder.csv',
    'block' : '../level/0/level_0_block.csv',
    'fall_block' :  '../level/0/level_0_fall_block.csv',
    'lock' : '../level/0/level_0_lock.csv',
}
