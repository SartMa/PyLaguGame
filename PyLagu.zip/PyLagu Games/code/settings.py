vertical_tile_number = 45
horizontal_tile_number = 80

tile_size = 16
tile_place=32

screen_height = vertical_tile_number*tile_size
screen_width = 1200

path = ''