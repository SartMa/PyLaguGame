<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="git" name="enemy" tilewidth="16" tileheight="16" tilecount="7680" columns="192">
 <image source="../graphics/enemy1/enemy.png" width="3072" height="640"/>
</tileset>
