<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="git" name="tile000" tilewidth="32" tileheight="32" tilecount="16" columns="4">
 <image source="../graphics/Monster/eye/idle/tile000.png" width="150" height="150"/>
</tileset>
