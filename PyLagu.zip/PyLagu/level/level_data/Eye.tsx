<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="git" name="tile001" tilewidth="16" tileheight="16" tilecount="81" columns="9">
 <image source="../graphics/Monster/Flyingeye/idle/tile001.png" width="150" height="150"/>
</tileset>
