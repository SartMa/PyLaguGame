<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="git" name="1" tilewidth="16" tileheight="16" tilecount="6" columns="3">
 <image source="../graphics/enemy/run/1.png" width="51" height="46"/>
</tileset>
