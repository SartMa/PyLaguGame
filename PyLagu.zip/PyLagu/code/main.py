import pygame as p
import time
from settings import *
from level import Level
from level_data import level_0
from player import Player
from pygame import mixer

p.init()
screen = p.display.set_mode((screen_width,screen_height))
# lol = p.Surface((screen_width, screen_height))

clock = p.time.Clock()
p.transform.scale(screen,(800,400))
level = Level(level_0, screen)
p.display.set_caption('PyLagu: Aetherial Pursuit')

mixer.init()
mixer.music.load('Ludum Dare 32 - Track 1.wav')
mixer.music.set_volume(0.7)
mixer.music.play(-1)

while True:
    for event in p.event.get():
        if event.type == p.QUIT:
            p.quit()
            exit()
    screen.fill('black')
    if(level.gameover):
        level=Level(level_0, screen)
    level.run()
    # scaled_lol = p.transform.smoothscale(lol, (screen.get_size()[0]*3, screen.get_size()[1]*3))

    # screen.blit(scaled_lol, (0, -screen_height*2))
    p.display.update()
    clock.tick(60)
